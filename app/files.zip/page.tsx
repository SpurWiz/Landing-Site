import Wrapper from "@/components/wrapper";
import Hero from "@/components/home/hero";
import WhyUnderperform from "@/components/home/why-underperform";
import IntegratedExpertise from "@/components/home/integrated-expertise";
import ProductPartners from "@/components/home/product-partners";
import LegacyLensSection from "@/components/home/legacy-lens";
import BuiltForFounders from "@/components/home/built-for-founders";
import Testimonials from "@/components/home/testimonials";
import CtaSection from "@/components/home/cta-section";
import React from "react";

const LandingPage = () => {
  return (
    <Wrapper>
      <Hero />
      <WhyUnderperform />
      <IntegratedExpertise />
      <ProductPartners />
      <LegacyLensSection />
      <BuiltForFounders />
      <Testimonials />
      <CtaSection />
    </Wrapper>
  );
};

export default LandingPage;
